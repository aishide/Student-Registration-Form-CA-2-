document.getElementById("feedbackForm").addEventListener("submit", function(e) {

    e.preventDefault(); // ✅ Prevent page reload (VERY IMPORTANT)

    let name = document.getElementById("name").value.trim();
    let email = document.getElementById("email").value.trim();
    let mobile = document.getElementById("mobile").value.trim();
    let department = document.getElementById("department").value;
    let feedback = document.getElementById("feedback").value.trim();
    let gender = document.querySelector('input[name="gender"]:checked');

    let errorMessage = "";

    // ✅ Name validation
    if (name === "") {
        errorMessage = "Name cannot be empty";
    }

    // ✅ Email validation
    else if (!email.match(/^[^ ]+@[^ ]+\.[a-z]{2,3}$/)) {
        errorMessage = "Invalid email format";
    }

    // ✅ Mobile validation
    else if (!mobile.match(/^[0-9]{10}$/)) {
        errorMessage = "Mobile must be 10 digits";
    }

    // ✅ Gender validation
    else if (!gender) {
        errorMessage = "Please select gender";
    }

    // ✅ Department validation
    else if (department === "") {
        errorMessage = "Please select department";
    }

    // ✅ Feedback validation (minimum 10 words)
    else if (feedback.split(/\s+/).length < 10) {
        errorMessage = "Feedback must be at least 10 words";
    }

    // ❌ If error exists
    if (errorMessage !== "") {
        document.getElementById("error").innerText = errorMessage;
    }

    // ✅ If all valid
    else {
        document.getElementById("error").innerText = "";

        // 🎉 Success popup
        alert("🎉 Thanks for submitting your feedback!");

        // 🔄 Reset form
        document.getElementById("feedbackForm").reset();
    }

});