from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
wait = WebDriverWait(driver, 10)

url = "file:///C:/Users/HP/OneDrive/Desktop/Student%20Registration%20Feedback%20Form/index.html"

# -------------------------------
# TEST 1: Page Load
# -------------------------------
try:
    driver.get(url)
    wait.until(EC.presence_of_element_located((By.ID, "name")))
    print("✅ Test 1 Passed: Form page opened successfully")
except:
    print("❌ Test 1 Failed")

# -------------------------------
# TEST 2: Valid Submission
# -------------------------------
try:
    driver.find_element(By.ID, "name").send_keys("Aishi De")
    driver.find_element(By.ID, "email").send_keys("test@gmail.com")
    driver.find_element(By.ID, "mobile").send_keys("9876543210")
    driver.find_element(By.ID, "department").send_keys("Computer Science")
    driver.find_element(By.XPATH, "//input[@value='Female']").click()
    driver.find_element(By.ID, "feedback").send_keys(
        "This form is very useful and I really liked using this system a lot"
    )

    driver.find_element(By.XPATH, "//button[text()='Submit']").click()

    # ✅ HANDLE ALERT (IMPORTANT FIX)
    wait.until(EC.alert_is_present())
    alert = driver.switch_to.alert
    alert.accept()

    print("✅ Test 2 Passed: Valid submission successful")

except Exception as e:
    print("❌ Test 2 Failed:", e)

# -------------------------------
# TEST 3: Empty Fields
# -------------------------------
try:
    driver.find_element(By.XPATH, "//button[text()='Reset']").click()
    time.sleep(1)

    driver.find_element(By.XPATH, "//button[text()='Submit']").click()

    wait.until(lambda d: d.find_element(By.ID, "error").text.strip() != "")

    error = driver.find_element(By.ID, "error").text.strip()

    if error.lower() == "name cannot be empty":
        print("✅ Test 3 Passed: Error shown for empty fields")
    else:
        print("❌ Test 3 Failed:", error)

except Exception as e:
    print("❌ Test 3 Failed:", e)

# -------------------------------
# TEST 4: Invalid Email
# -------------------------------
try:
    driver.find_element(By.XPATH, "//button[text()='Reset']").click()

    driver.find_element(By.ID, "name").send_keys("Aishi")
    driver.find_element(By.ID, "email").send_keys("wrongemail")
    driver.find_element(By.ID, "mobile").send_keys("9876543210")

    driver.find_element(By.XPATH, "//button[text()='Submit']").click()
    time.sleep(1)

    error = driver.find_element(By.ID, "error").text

    if "email" in error.lower():
        print("✅ Test 4 Passed: Invalid email detected")
    else:
        print("❌ Test 4 Failed")

except:
    print("❌ Test 4 Failed")

# -------------------------------
# TEST 5: Invalid Mobile
# -------------------------------
try:
    driver.find_element(By.XPATH, "//button[text()='Reset']").click()

    driver.find_element(By.ID, "name").send_keys("Aishi")
    driver.find_element(By.ID, "email").send_keys("test@gmail.com")
    driver.find_element(By.ID, "mobile").send_keys("123")

    driver.find_element(By.XPATH, "//button[text()='Submit']").click()
    time.sleep(1)

    error = driver.find_element(By.ID, "error").text

    if "mobile" in error.lower():
        print("✅ Test 5 Passed: Invalid mobile detected")
    else:
        print("❌ Test 5 Failed")

except:
    print("❌ Test 5 Failed")

# -------------------------------
# TEST 6: Dropdown Check
# -------------------------------
try:
    driver.find_element(By.XPATH, "//button[text()='Reset']").click()

    dropdown = driver.find_element(By.ID, "department")
    dropdown.send_keys("IT")

    if dropdown.get_attribute("value") != "":
        print("✅ Test 6 Passed: Dropdown working")
    else:
        print("❌ Test 6 Failed")

except:
    print("❌ Test 6 Failed")

# -------------------------------
# TEST 7: Buttons Check
# -------------------------------
try:
    driver.find_element(By.ID, "name").send_keys("Test")

    driver.find_element(By.XPATH, "//button[text()='Reset']").click()

    name = driver.find_element(By.ID, "name").get_attribute("value")

    if name == "":
        print("✅ Test 7 Passed: Reset button working")
    else:
        print("❌ Test 7 Failed")

    print("✅ Submit button already tested above")

except:
    print("❌ Test 7 Failed")

driver.quit()